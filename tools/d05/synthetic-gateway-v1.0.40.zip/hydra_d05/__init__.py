"""HYDRA D05 isolated synthetic accounting prototype, NOT production enforcement."""
from .ledger import Ledger, LedgerError
