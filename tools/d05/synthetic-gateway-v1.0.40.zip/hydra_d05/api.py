"""Loopback-only HTTP façade for the isolated synthetic SQLite D05 prototype.
No production routing, no external hosting, no real Owner grant verification.
"""
import os
import json
import secrets
from fastapi import FastAPI, Depends, Header, HTTPException
from pydantic import BaseModel, ConfigDict, Field
from .ledger import Ledger, LedgerError

class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

class CaseIn(StrictModel):
    case_id: str
    group_id: str
    fingerprint: str
    prereg_digest: str
class GrantIn(StrictModel):
    grant_id: str
    case_id: str
    actor: str
    environment: str
    operation: str
    severity: str
    intent_digest: str
    ttl_seconds: int = Field(ge=1,le=86400)
class AdmitIn(StrictModel):
    case_id: str
    actor: str
    environment: str
    operation: str
    intent_digest: str
    grant_id: str
    idempotency_key: str
    severity: str = "MINOR"
class DispatchIn(StrictModel):
    attempt_id: str
    actor: str
    environment: str
    operation: str
class StartIn(StrictModel):
    attempt_id: str
    single_use_token: str
    receipt_sha256: str
class FinishIn(StrictModel):
    attempt_id: str
    outcome: str
class UnknownIn(StrictModel):
    attempt_id: str
    reason_code: str
class CancelIn(StrictModel):
    attempt_id: str
    proof_digest: str


def create_app(db_path, *, admin_key, runner_keys, audit_key):
    if not isinstance(runner_keys,dict) or not runner_keys:
        raise ValueError("Explicit individual runner credentials required")
    if any(not isinstance(actor,str) or not actor or not isinstance(key,str) for actor,key in runner_keys.items()):
        raise ValueError("Invalid runner credential mapping")
    keys={"admin":admin_key,"audit":audit_key,**{f"runner:{actor}":secret for actor,secret in runner_keys.items()}}
    if any(not isinstance(k,str) or len(k)<32 for k in keys.values()) or len(set(keys.values()))!=len(keys):
        raise ValueError("Distinct high-entropy credentials >=32 chars required; no defaults")
    ledger=Ledger(db_path)
    app=FastAPI(title="HYDRA D05 isolated prototype",version="0.1.0",docs_url=None,redoc_url=None,openapi_url=None)
    app.state.ledger=ledger

    def require(*roles):
        def guard(x_api_key: str | None=Header(default=None)):
            if not x_api_key or not any(secrets.compare_digest(x_api_key,keys[role]) for role in roles):
                raise HTTPException(401,"Unauthorized")
            return True
        return guard

    def authenticated_runner(x_api_key: str | None=Header(default=None)):
        if not x_api_key:
            raise HTTPException(401,"Unauthorized")
        for actor, secret in runner_keys.items():
            if secrets.compare_digest(x_api_key, secret):
                return actor
        raise HTTPException(401,"Unauthorized")

    def assert_attempt_owned(attempt_id, actor):
        try:
            actual=ledger.attempt_actor(attempt_id)
        except LedgerError:
            raise HTTPException(409,"Attempt not found") from None
        if actual != actor:
            raise HTTPException(403,"Runner does not own attempt")

    def act(fn, **kwargs):
        try:return fn(**kwargs)
        except LedgerError as e:
            raise HTTPException(status_code=400 if e.code=="INVALID_INPUT" else 409,
                                detail={"code":e.code,"message":str(e)}) from None

    @app.get("/health")
    def health():return {"service":"synthetic-single-host", "status":"ready", "production_ready":False}
    @app.post("/admin/cases",dependencies=[Depends(require("admin"))])
    def case(payload: CaseIn):return act(ledger.register_case,**payload.model_dump())
    @app.post("/admin/grants",dependencies=[Depends(require("admin"))])
    def grant(payload: GrantIn):return act(ledger.issue_grant,**payload.model_dump())
    @app.post("/admin/grants/{grant_id}/revoke",dependencies=[Depends(require("admin"))])
    def revoke(grant_id:str):return act(ledger.revoke_grant,grant_id=grant_id)
    @app.post("/runner/admit")
    def admit(payload: AdmitIn, actor: str=Depends(authenticated_runner)):
        if payload.actor!=actor: raise HTTPException(403,"Runner identity mismatch")
        return act(ledger.admit,**payload.model_dump())
    @app.post("/runner/dispatch")
    def dispatch(payload: DispatchIn, actor: str=Depends(authenticated_runner)):
        if payload.actor!=actor: raise HTTPException(403,"Runner identity mismatch")
        assert_attempt_owned(payload.attempt_id,actor)
        return act(ledger.claim_dispatch,**payload.model_dump())
    @app.post("/runner/start")
    def start(payload: StartIn, actor: str=Depends(authenticated_runner)):
        assert_attempt_owned(payload.attempt_id,actor)
        return act(ledger.record_start,**payload.model_dump())
    @app.post("/runner/finish")
    def finish(payload: FinishIn, actor: str=Depends(authenticated_runner)):
        assert_attempt_owned(payload.attempt_id,actor)
        return act(ledger.finish,**payload.model_dump())
    @app.post("/runner/unknown")
    def unknown(payload: UnknownIn, actor: str=Depends(authenticated_runner)):
        assert_attempt_owned(payload.attempt_id,actor)
        return act(ledger.mark_unknown,**payload.model_dump())
    @app.post("/admin/cancel-unstarted",dependencies=[Depends(require("admin"))])
    def cancel(payload: CancelIn):return act(ledger.cancel_reserved_unstarted,**payload.model_dump())
    @app.get("/audit/groups/{group_id}",dependencies=[Depends(require("admin","audit"))])
    def snapshot(group_id:str):return act(ledger.snapshot,group_id=group_id)
    @app.get("/audit/integrity",dependencies=[Depends(require("admin","audit"))])
    def integrity():return act(ledger.verify_audit_chain)
    return app


def main():
    import uvicorn
    bind=os.getenv("HYDRA_D05_BIND","127.0.0.1")
    if bind not in ("127.0.0.1","::1"):
        raise SystemExit("Refusing non-loopback binding in isolated prototype")
    app=create_app(os.environ["HYDRA_D05_DB"],
                   admin_key=os.environ["HYDRA_D05_ADMIN_KEY"],
                   runner_keys=json.loads(os.environ["HYDRA_D05_RUNNER_KEYS_JSON"]),
                   audit_key=os.environ["HYDRA_D05_AUDIT_KEY"])
    uvicorn.run(app,host=bind,port=int(os.getenv("HYDRA_D05_PORT","8765")),access_log=False)

if __name__=="__main__":main()
