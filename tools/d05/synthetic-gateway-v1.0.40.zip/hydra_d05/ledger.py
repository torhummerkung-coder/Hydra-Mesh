"""Single-host, SQLite-backed D05 reference gateway.

Never use as a production/clinical admission service. Owner-authorized synthetic data only.
"""
import contextlib
import hashlib
import json
import re
import secrets
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path

CAPS = {"MINOR": 8, "MAJOR": 5}
ACTIVE_RETRY = ("RESERVED", "DISPATCHED", "UNKNOWN", "STARTED", "FINISHED")
DIGEST_RE = re.compile(r"^[a-f0-9]{64}$")
ID_RE = re.compile(r"^[A-Za-z0-9_.:@-]{1,128}$")

class LedgerError(RuntimeError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def require_identifier(value, name):
    if not isinstance(value, str) or not ID_RE.fullmatch(value):
        raise LedgerError("INVALID_INPUT", f"{name}: invalid identifier")
    return value


def require_digest(value, name):
    if not isinstance(value, str) or not DIGEST_RE.fullmatch(value):
        raise LedgerError("INVALID_INPUT", f"{name}: expected lowercase SHA-256 hex")
    return value


def utc_now():
    return time.time()


def canon(payload):
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS groups (
 group_id TEXT PRIMARY KEY, minor_cap INTEGER NOT NULL CHECK(minor_cap=8),
 major_cap INTEGER NOT NULL CHECK(major_cap=5)
);
CREATE TABLE IF NOT EXISTS cases (
 case_id TEXT PRIMARY KEY, group_id TEXT NOT NULL REFERENCES groups(group_id),
 fingerprint TEXT NOT NULL UNIQUE, prereg_digest TEXT NOT NULL,
 registered_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS grants (
 grant_id TEXT PRIMARY KEY, case_id TEXT NOT NULL REFERENCES cases(case_id),
 actor TEXT NOT NULL, environment TEXT NOT NULL, operation TEXT NOT NULL, severity TEXT NOT NULL CHECK(severity IN ('MINOR','MAJOR')),
 intent_digest TEXT NOT NULL, expires_at REAL NOT NULL,
 revoked INTEGER NOT NULL DEFAULT 0 CHECK(revoked IN (0,1)),
 issued_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS attempts (
 attempt_id TEXT PRIMARY KEY, case_id TEXT NOT NULL REFERENCES cases(case_id),
 group_id TEXT NOT NULL REFERENCES groups(group_id),
 grant_id TEXT NOT NULL REFERENCES grants(grant_id),
 actor TEXT NOT NULL, environment TEXT NOT NULL, operation TEXT NOT NULL,
 intent_digest TEXT NOT NULL, idempotency_key TEXT NOT NULL UNIQUE,
 kind TEXT NOT NULL CHECK(kind IN ('FIRST','RETRY')),
 severity TEXT NOT NULL CHECK(severity IN ('MINOR','MAJOR')),
 state TEXT NOT NULL CHECK(state IN ('RESERVED','DISPATCHED','UNKNOWN','STARTED','FINISHED','CANCELLED')),
 dispatch_token_hash TEXT, start_receipt_hash TEXT, outcome TEXT,
 created_at REAL NOT NULL, updated_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS attempts_group_state ON attempts(group_id,kind,severity,state);
CREATE INDEX IF NOT EXISTS attempts_case ON attempts(case_id,state);
CREATE UNIQUE INDEX IF NOT EXISTS only_one_live_first ON attempts(case_id)
 WHERE kind='FIRST' AND state!='CANCELLED';
CREATE TABLE IF NOT EXISTS outbox (
 attempt_id TEXT PRIMARY KEY REFERENCES attempts(attempt_id),
 state TEXT NOT NULL CHECK(state IN ('PENDING','CLAIMED','BLOCKED','COMPLETED','CANCELLED')),
 created_at REAL NOT NULL, updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
 seq INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL,
 ref TEXT NOT NULL, payload_json TEXT NOT NULL,
 previous_hash TEXT NOT NULL, event_hash TEXT NOT NULL UNIQUE,
 created_at REAL NOT NULL
);
"""


class Ledger:
    def __init__(self, db_path):
        self.path = str(Path(db_path).resolve())
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        # WAL is a database-level setting: do not toggle it per concurrent connection.
        init_con = sqlite3.connect(self.path, timeout=20)
        try:
            init_con.execute("PRAGMA busy_timeout=20000")
            version=init_con.execute("PRAGMA user_version").fetchone()[0]
            if version==0:
                if init_con.execute("PRAGMA journal_mode").fetchone()[0].lower()!="wal":
                    init_con.execute("PRAGMA journal_mode=WAL")
                init_con.executescript(SCHEMA)
                init_con.execute("PRAGMA user_version=1")
            elif version!=1:
                raise LedgerError("SCHEMA_VERSION_HOLD","unknown database schema version")
            init_con.commit()
        finally:
            init_con.close()

    def _conn(self):
        con = sqlite3.connect(self.path, timeout=20, isolation_level=None)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        con.execute("PRAGMA busy_timeout=20000")
        con.execute("PRAGMA synchronous=FULL")
        return con

    @contextlib.contextmanager
    def _tx(self):
        con = self._conn()
        try:
            con.execute("BEGIN IMMEDIATE")
            yield con
            con.commit()
        except BaseException:
            con.rollback()
            raise
        finally:
            con.close()

    @staticmethod
    def _event(con, kind, ref, payload):
        prev = con.execute("SELECT event_hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
        p_hash = prev[0] if prev else "0" * 64
        p_json = canon(payload)
        h = hashlib.sha256((p_hash + "\n" + kind + "\n" + ref + "\n" + p_json).encode()).hexdigest()
        con.execute("INSERT INTO events(kind,ref,payload_json,previous_hash,event_hash,created_at) VALUES(?,?,?,?,?,?)",
                    (kind, ref, p_json, p_hash, h, utc_now()))

    def register_case(self, *, case_id, group_id, fingerprint, prereg_digest):
        require_identifier(case_id, "case_id")
        require_identifier(group_id, "group_id")
        require_digest(fingerprint, "fingerprint")
        require_digest(prereg_digest, "prereg_digest")
        with self._tx() as con:
            r = con.execute("SELECT * FROM cases WHERE case_id=? OR fingerprint=?", (case_id, fingerprint)).fetchone()
            if r:
                if (r["case_id"], r["group_id"], r["fingerprint"], r["prereg_digest"]) == (case_id,group_id,fingerprint,prereg_digest):
                    return {"case_id": case_id, "status": "EXISTS_SAME_RECORD"}
                raise LedgerError("CANONICAL_COLLISION_HOLD", "case ID or fingerprint already bound to another preregistration")
            con.execute("INSERT OR IGNORE INTO groups VALUES(?,?,?)", (group_id, 8, 5))
            con.execute("INSERT INTO cases VALUES(?,?,?,?,?)", (case_id,group_id,fingerprint,prereg_digest,utc_now()))
            self._event(con, "CASE_REGISTERED",case_id,{"group_id":group_id,"fingerprint":fingerprint,"prereg_digest":prereg_digest})
            return {"case_id":case_id,"status":"REGISTERED"}

    def issue_grant(self, *, grant_id, case_id, actor, environment, operation, severity, intent_digest, ttl_seconds):
        for name,value in (("grant_id",grant_id),("case_id",case_id),("actor",actor),
                           ("environment",environment),("operation",operation)):
            require_identifier(value, name)
        require_digest(intent_digest, "intent_digest")
        if severity not in CAPS: raise LedgerError("CLASSIFICATION_HOLD","grant severity invalid")
        if not isinstance(ttl_seconds,(int,float)) or isinstance(ttl_seconds,bool) or not 1 <= ttl_seconds <= 86400:
            raise LedgerError("INVALID_INPUT","ttl_seconds must be 1..86400")
        with self._tx() as con:
            if not con.execute("SELECT 1 FROM cases WHERE case_id=?",(case_id,)).fetchone():
                raise LedgerError("UNREGISTERED_HOLD","case not preregistered")
            values=(grant_id,case_id,actor,environment,operation,severity,intent_digest,utc_now()+ttl_seconds,0,utc_now())
            try:
                con.execute("INSERT INTO grants VALUES(?,?,?,?,?,?,?,?,?,?)",values)
            except sqlite3.IntegrityError:
                raise LedgerError("DUPLICATE_GRANT_HOLD","grant id cannot be reused") from None
            self._event(con,"GRANT_ISSUED",grant_id,{"case_id":case_id,"actor":actor,"environment":environment,"operation":operation,"severity":severity,"intent_digest":intent_digest,"ttl_seconds":ttl_seconds})
            return {"grant_id":grant_id,"status":"ISSUED"}

    def revoke_grant(self, grant_id):
        require_identifier(grant_id,"grant_id")
        with self._tx() as con:
            grant=con.execute("SELECT * FROM grants WHERE grant_id=?",(grant_id,)).fetchone()
            if not grant: raise LedgerError("UNKNOWN_GRANT_HOLD","grant missing")
            if not grant["revoked"]:
                con.execute("UPDATE grants SET revoked=1 WHERE grant_id=?",(grant_id,))
                # Any in-flight dispatch becomes ambiguous; do not silently refund it.
                con.execute("UPDATE attempts SET state='UNKNOWN',updated_at=? WHERE grant_id=? AND state='DISPATCHED'",(utc_now(),grant_id))
                con.execute("UPDATE outbox SET state='BLOCKED',updated_at=? WHERE attempt_id IN (SELECT attempt_id FROM attempts WHERE grant_id=? AND state IN ('RESERVED','UNKNOWN'))",(utc_now(),grant_id))
                self._event(con,"GRANT_REVOKED",grant_id,{"case_id":grant["case_id"],"in_flight_dispatch":"UNKNOWN_HOLD"})
            return {"grant_id":grant_id,"status":"REVOKED"}

    @staticmethod
    def _valid_grant(con, grant_id, case_id, actor, environment, operation, intent_digest):
        grant=con.execute("SELECT * FROM grants WHERE grant_id=?",(grant_id,)).fetchone()
        if not grant: raise LedgerError("D03_GRANT_HOLD","grant missing")
        if (grant["case_id"],grant["actor"],grant["environment"],grant["operation"],grant["intent_digest"]) != (case_id,actor,environment,operation,intent_digest):
            raise LedgerError("D03_SCOPE_HOLD","grant does not match exact principal, environment, case, operation and intent")
        if grant["revoked"] or grant["expires_at"] <= utc_now():
            raise LedgerError("D03_REVOKED_OR_EXPIRED_HOLD","grant unavailable at point of use")
        return grant

    def admit(self, *, case_id, actor, environment, operation, intent_digest, grant_id, idempotency_key, severity="MINOR"):
        for name,value in (("case_id",case_id),("actor",actor),("environment",environment),
                           ("operation",operation),("grant_id",grant_id),("idempotency_key",idempotency_key)):
            require_identifier(value,name)
        require_digest(intent_digest,"intent_digest")
        if severity not in CAPS: raise LedgerError("CLASSIFICATION_HOLD","unknown severity")
        with self._tx() as con:
            previous=con.execute("SELECT * FROM attempts WHERE idempotency_key=?",(idempotency_key,)).fetchone()
            if previous:
                req=(case_id,actor,environment,operation,intent_digest,grant_id,severity)
                prior=tuple(previous[k] for k in ("case_id","actor","environment","operation","intent_digest","grant_id","severity"))
                if req != prior: raise LedgerError("IDEMPOTENCY_MISMATCH_HOLD","same key, altered immutable intent")
                return {"attempt_id":previous["attempt_id"],"kind":previous["kind"],"state":previous["state"],"idempotent_replay":True}
            case=con.execute("SELECT * FROM cases WHERE case_id=?",(case_id,)).fetchone()
            if not case: raise LedgerError("UNREGISTERED_HOLD","case missing")
            validated_grant=self._valid_grant(con,grant_id,case_id,actor,environment,operation,intent_digest)
            if validated_grant["severity"]!=severity:
                raise LedgerError("CLASSIFICATION_HOLD","attempt severity does not match authorized grant")
            attempts=con.execute("SELECT kind,state FROM attempts WHERE case_id=?",(case_id,)).fetchall()
            active_first=[a for a in attempts if a["kind"]=="FIRST" and a["state"]!="CANCELLED"]
            if not active_first:
                kind="FIRST"
            elif active_first[0]["state"] not in ("STARTED","FINISHED"):
                raise LedgerError("FIRST_UNKNOWN_OR_RESERVED_HOLD","first attempt not proven started or cancelled")
            else:
                kind="RETRY"
            if kind=="RETRY":
                count=con.execute("SELECT COUNT(*) FROM attempts WHERE group_id=? AND kind='RETRY' AND severity=? AND state IN ('RESERVED','DISPATCHED','UNKNOWN','STARTED','FINISHED')",
                                  (case["group_id"],severity)).fetchone()[0]
                if count>=CAPS[severity]:
                    raise LedgerError("SHARED_RETRY_CAP_HOLD","shared group cap exhausted or reserved")
            attempt_id="attempt-"+secrets.token_hex(16)
            now=utc_now()
            con.execute("INSERT INTO attempts(attempt_id,case_id,group_id,grant_id,actor,environment,operation,intent_digest,idempotency_key,kind,severity,state,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (attempt_id,case_id,case["group_id"],grant_id,actor,environment,operation,intent_digest,idempotency_key,kind,severity,"RESERVED",now,now))
            con.execute("INSERT INTO outbox VALUES(?,?,?,?)",(attempt_id,"PENDING",now,now))
            self._event(con,"ADMITTED",attempt_id,{"case_id":case_id,"group_id":case["group_id"],"kind":kind,"severity":severity,"actor":actor,"operation":operation,"grant_id":grant_id})
            return {"attempt_id":attempt_id,"kind":kind,"state":"RESERVED","idempotent_replay":False}

    def claim_dispatch(self, *, attempt_id, actor, environment, operation):
        for name,val in (("attempt_id",attempt_id),("actor",actor),("environment",environment),("operation",operation)):
            require_identifier(val,name)
        with self._tx() as con:
            a=con.execute("SELECT * FROM attempts WHERE attempt_id=?",(attempt_id,)).fetchone()
            if not a: raise LedgerError("UNKNOWN_ATTEMPT_HOLD","attempt missing")
            if a["state"]!="RESERVED": raise LedgerError("DISPATCH_STATE_HOLD","dispatch requires RESERVED state")
            self._valid_grant(con,a["grant_id"],a["case_id"],actor,environment,operation,a["intent_digest"])
            if (a["actor"],a["environment"],a["operation"])!=(actor,environment,operation):
                raise LedgerError("D03_SCOPE_HOLD","dispatch scope differs")
            token=secrets.token_urlsafe(32)
            token_hash=hashlib.sha256(token.encode()).hexdigest()
            con.execute("UPDATE attempts SET state='DISPATCHED',dispatch_token_hash=?,updated_at=? WHERE attempt_id=?",(token_hash,utc_now(),attempt_id))
            con.execute("UPDATE outbox SET state='CLAIMED',updated_at=? WHERE attempt_id=?",(utc_now(),attempt_id))
            self._event(con,"DISPATCH_CLAIMED",attempt_id,{"actor":actor,"environment":environment,"operation":operation})
            return {"attempt_id":attempt_id,"state":"DISPATCHED","single_use_token":token}

    def record_start(self, *, attempt_id, single_use_token, receipt_sha256):
        require_identifier(attempt_id,"attempt_id")
        require_digest(receipt_sha256,"receipt_sha256")
        if not isinstance(single_use_token,str) or len(single_use_token)>256:
            raise LedgerError("INVALID_INPUT","token invalid")
        with self._tx() as con:
            a=con.execute("SELECT * FROM attempts WHERE attempt_id=?",(attempt_id,)).fetchone()
            if not a: raise LedgerError("UNKNOWN_ATTEMPT_HOLD","attempt missing")
            token_hash=hashlib.sha256(single_use_token.encode()).hexdigest()
            if not a["dispatch_token_hash"] or not secrets.compare_digest(a["dispatch_token_hash"],token_hash):
                raise LedgerError("START_PROOF_HOLD","dispatch token mismatch")
            if a["state"] not in ("DISPATCHED","UNKNOWN"):
                raise LedgerError("START_STATE_HOLD","start requires dispatched or unknown proof reconciliation")
            # Revalidate before treating the start as admissible; a revoked dispatch stays on HOLD.
            self._valid_grant(con,a["grant_id"],a["case_id"],a["actor"],a["environment"],a["operation"],a["intent_digest"])
            con.execute("UPDATE attempts SET state='STARTED',start_receipt_hash=?,dispatch_token_hash=NULL,updated_at=? WHERE attempt_id=?",(receipt_sha256,utc_now(),attempt_id))
            con.execute("UPDATE outbox SET state='COMPLETED',updated_at=? WHERE attempt_id=?",(utc_now(),attempt_id))
            self._event(con,"START_ATTESTED",attempt_id,{"receipt_sha256":receipt_sha256})
            return {"attempt_id":attempt_id,"state":"STARTED"}

    def finish(self, *, attempt_id, outcome):
        require_identifier(attempt_id,"attempt_id")
        if outcome not in ("PASS","FAIL","TIMEOUT"):
            raise LedgerError("INVALID_INPUT","outcome must PASS, FAIL or TIMEOUT")
        with self._tx() as con:
            a=con.execute("SELECT * FROM attempts WHERE attempt_id=?",(attempt_id,)).fetchone()
            if not a or a["state"]!="STARTED":
                raise LedgerError("FINISH_STATE_HOLD","finish requires STARTED")
            con.execute("UPDATE attempts SET state='FINISHED',outcome=?,updated_at=? WHERE attempt_id=?",(outcome,utc_now(),attempt_id))
            self._event(con,"FINISHED",attempt_id,{"outcome":outcome})
            return {"attempt_id":attempt_id,"state":"FINISHED","outcome":outcome}

    def mark_unknown(self, *, attempt_id, reason_code):
        require_identifier(attempt_id,"attempt_id")
        require_identifier(reason_code,"reason_code")
        with self._tx() as con:
            a=con.execute("SELECT * FROM attempts WHERE attempt_id=?",(attempt_id,)).fetchone()
            if not a or a["state"] not in ("RESERVED","DISPATCHED"):
                raise LedgerError("UNKNOWN_STATE_HOLD","only unresolved reservations/dispatch can enter UNKNOWN")
            con.execute("UPDATE attempts SET state='UNKNOWN',updated_at=? WHERE attempt_id=?",(utc_now(),attempt_id))
            con.execute("UPDATE outbox SET state='BLOCKED',updated_at=? WHERE attempt_id=?",(utc_now(),attempt_id))
            self._event(con,"UNKNOWN_HOLD",attempt_id,{"reason_code":reason_code})
            return {"attempt_id":attempt_id,"state":"UNKNOWN"}

    def cancel_reserved_unstarted(self, *, attempt_id, proof_digest):
        require_identifier(attempt_id,"attempt_id")
        require_digest(proof_digest,"proof_digest")
        with self._tx() as con:
            a=con.execute("SELECT * FROM attempts WHERE attempt_id=?",(attempt_id,)).fetchone()
            if not a or a["state"]!="RESERVED" or a["dispatch_token_hash"]:
                raise LedgerError("CANCELLATION_HOLD","cannot safely cancel after dispatch or uncertain start")
            con.execute("UPDATE attempts SET state='CANCELLED',updated_at=? WHERE attempt_id=?",(utc_now(),attempt_id))
            con.execute("UPDATE outbox SET state='CANCELLED',updated_at=? WHERE attempt_id=?",(utc_now(),attempt_id))
            self._event(con,"CANCELLED_BEFORE_DISPATCH",attempt_id,{"proof_digest":proof_digest})
            return {"attempt_id":attempt_id,"state":"CANCELLED"}

    def attempt_actor(self, attempt_id):
        require_identifier(attempt_id,"attempt_id")
        con=self._conn()
        try:
            row=con.execute("SELECT actor FROM attempts WHERE attempt_id=?",(attempt_id,)).fetchone()
            if not row: raise LedgerError("UNKNOWN_ATTEMPT_HOLD","attempt absent")
            return row["actor"]
        finally:
            con.close()

    def snapshot(self, group_id):
        require_identifier(group_id,"group_id")
        with contextlib.closing(self._conn()) as con:
            if not con.execute("SELECT 1 FROM groups WHERE group_id=?",(group_id,)).fetchone():
                raise LedgerError("UNKNOWN_GROUP","group absent")
            result={"group_id":group_id,"limits":dict(CAPS),"first_started":0,"first_pending":0,
                    "retry_minor_reserved_or_consumed":0,"retry_major_reserved_or_consumed":0,
                    "unknown_attempts":0}
            for r in con.execute("SELECT kind,severity,state FROM attempts WHERE group_id=?",(group_id,)):
                if r["kind"]=="FIRST":
                    if r["state"] in ("STARTED","FINISHED"): result["first_started"]+=1
                    elif r["state"] in ("RESERVED","DISPATCHED","UNKNOWN"): result["first_pending"]+=1
                if r["kind"]=="RETRY" and r["state"] in ACTIVE_RETRY:
                    result["retry_"+r["severity"].lower()+"_reserved_or_consumed"]+=1
                if r["state"]=="UNKNOWN":result["unknown_attempts"]+=1
            return result

    def verify_audit_chain(self):
        with contextlib.closing(self._conn()) as con:
            prev="0"*64
            count=0
            for e in con.execute("SELECT * FROM events ORDER BY seq ASC"):
                calc=hashlib.sha256((prev+"\n"+e["kind"]+"\n"+e["ref"]+"\n"+e["payload_json"]).encode()).hexdigest()
                if e["previous_hash"]!=prev or e["event_hash"]!=calc:
                    raise LedgerError("AUDIT_INTEGRITY_FAIL",f"broken chain at seq {e['seq']}")
                prev=calc
                count+=1
            return {"chain_valid":True,"event_count":count,"tip_sha256":prev,
                    "note":"Not independently anchored; DB administrator can rewrite entire chain"}
